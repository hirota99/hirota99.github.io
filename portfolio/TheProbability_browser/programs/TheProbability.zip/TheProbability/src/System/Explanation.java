package System;

public class Explanation {

    public static void gameStart() {
        System.out.println();
        System.out.println("【 The Probability 】");
        System.out.println();
        Action.actionStop1second();  //1秒間停止

        while (true) {
            System.out.println("ゲーム開始はキーを押してください");

            try {
                int keyCode = System.in.read();
                if (keyCode == 10) { // EnterキーのASCIIコード
                    System.out.println("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■");
                    System.out.println();
                    break; // Enterキーが押されたらループを抜ける
                } else {
                    System.out.println("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■");
                    System.out.println();
                    break;
                }
            } catch (Exception e) {
                System.err.println("エラーが発生しました。");
            }
        }

        return;
    }

    public static void openingExplanation() {
        System.out.println("このゲームは1/2の確率を当て続けてゴールを目指すゲームです。");
        Action.actionStop1second();  //1秒間停止
        Action.actionStop1second();  //1秒間停止
        System.out.println("右か左か完全にランダムの正解を、20回連続で当て続ける必要があります。");
        Action.actionStop1second();  //1秒間停止
        Action.actionStop1second();  //1秒間停止
        System.out.println("成功した暁には、あなたは『1/1,048,576』の確率を当てた幸運の持ち主となります。");
        Action.actionStop1second();  //1秒間停止
        Action.actionStop1second();  //1秒間停止
        System.out.println("ただし、途中で失敗したら最初からやり直しになりますのでご注意ください。");
        Action.actionStop1second();  //1秒間停止
        Action.actionStop1second();  //1秒間停止
        System.out.println("それでは、あなたの運を見せてもらいましょう・・・");
        Action.actionStop3second();  //3秒間停止
        Action.actionStop1second();  //1秒間停止
    }
}
