package System;

import java.util.ArrayList;

public class ChoiceHistory {
    private ArrayList<String> history;

    // コンストラクタ
    public ChoiceHistory() {
        history = new ArrayList<>();
    }

    // 選択を履歴に追加するメソッド
    public void addChoice(String choice) {
        history.add(choice);
    }

    // 履歴を表示するメソッド
    public void displayHistory() {
        if (history.size() < 1) {
            System.err.println("まだ選択履歴はありません。");
        } else {
            System.out.print("選択履歴: ");

            for (int i = 0; i < history.size(); i++) {
                System.out.print(history.get(i) + " ");
                Action.actionStophalfsecond(); // 0.5秒あける
            }
        }
        System.out.println();
    }

    // 履歴をクリアするメソッド
    public void clearHistory() {
        history.clear();
    }
}
