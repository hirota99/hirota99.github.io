package System;

public class ChooseAction {
    
    public static int chooseAction(String choose) {
        int chooseNumber = 0;
        switch (choose) {
            case "A":
            case "a":
                chooseNumber = 1;
                break;
            case "D":
            case "d":
                chooseNumber = 2;
                break;
            case "S":
            case "s":
                chooseNumber = 10;
                break;

            default:
                System.out.println("エラーが発生しました。正しいキーを押してください。");
                break;
        }
        return chooseNumber;
    }

}
