package System;

public class Action {

    public static void actionStophalfsecond() {
        try {
            Thread.sleep(500); // 0.5秒間だけ処理を止める
        } catch (InterruptedException e) {
        }
    }
    
    public static void actionStop1second() {
        try {
            Thread.sleep(1000); // 1秒間だけ処理を止める
        } catch (InterruptedException e) {
        }
    }

    public static void actionStop3second() {
        try {
            Thread.sleep(3000); // 3秒間だけ処理を止める
        } catch (InterruptedException e) {
        }
    }


    public static void result(int floor) {
        if(floor <= 349525){
            resultEarly();
        }else if(floor >= 349525 && floor <= 699050){
            resultMidfield();
        }else{
            resultFinal();
        }

    }

    public static void resultEarly() {  //・・・をゆっくり出すメソッド
        System.out.print("・");
        actionStophalfsecond();// 0.5秒
        System.out.print("・");
        actionStophalfsecond();// 0.5秒
        System.out.print("・");
        actionStophalfsecond();// 0.5秒
        System.out.print("・");
        actionStophalfsecond();// 0.5秒
        System.out.print("・");
        actionStophalfsecond();// 0.5秒
        System.out.print("・");
        actionStop1second();  //最後は1秒間止めて溜める
    }

    public static void resultMidfield() {
        System.out.print("・");
        actionStop1second();// 1秒
        System.out.print("・");
        actionStop1second();// 1秒
        System.out.print("・");
        actionStop1second();// 1秒
        System.out.print("・");
        actionStop1second();// 1秒
        System.out.print("・");
        actionStop1second();// 1秒
        System.out.print("・");
        actionStop3second();  //最後は3秒間止めて溜める
    }

    public static void resultFinal() {
        System.out.print("・");
        actionStop3second();// 3秒
        System.out.print("・");
        actionStop3second();// 3秒
        System.out.print("・");
        actionStop3second();// 3秒
        System.out.print("・");
        actionStop3second();// 3秒
        System.out.print("・");
        actionStop3second();// 3秒
        System.out.print("・");
        actionStop3second();  //最後は5秒間止めて溜める
        actionStop1second();
        actionStop1second();
    }

}
