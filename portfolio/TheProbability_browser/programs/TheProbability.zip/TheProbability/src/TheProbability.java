import System.*;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class TheProbability {

    public static void main(String[] args) {
        boolean exit = false;
        Scanner scanner = new Scanner(System.in);
        ChoiceHistory choiceHistory = new ChoiceHistory();  // ChoiceHistoryクラスのインスタンスを作成

        Explanation.gameStart();

        try {
            while (!exit) {
                Explanation.openingExplanation();

                int floor = 1; // 確率計算を初期化する
                choiceHistory.clearHistory();  // ゲーム開始時に履歴をクリア

                while (true) {

                    if (floor == 1048576) {
                        System.out.println("ゲームクリア！！今すぐに宝くじを買いに行くことをおすすめします！");
                        break;
                    }

                    System.out.println();
                    System.out.println("進む部屋をAかDで選択してください。");
                    System.out.println("今までの選択肢を確認する場合はSを押してください。");

                    int chooseNumber = 0;
                    String choose = scanner.next();
                    chooseNumber = ChooseAction.chooseAction(choose); // スイッチ文で入力文字列を数値に変換

                    if (chooseNumber == 10) { //スイッチ文で「S」が押されたことを検出した場合
                        choiceHistory.displayHistory();// 選択肢の履歴を表示するクラス
                        continue;
                    } else if (chooseNumber == 1 || chooseNumber == 2) { // どちらかの扉を開いたら〜
                        Random rand = new Random();
                        int correctFloor = rand.nextInt(2) + 1;

                        choiceHistory.addChoice(choose.equalsIgnoreCase("A") ? "A" : "D");
                        Action.result(floor);

                        if (chooseNumber == correctFloor) { // 正解なら
                            System.out.println("成功！");
                            floor = floor * 2;
                        } else { // 不正解なら
                            System.out.println("失敗");
                            Action.actionStop1second(); // 1秒間開ける
                            System.out.println("ゲームオーバー");
                            Action.actionStop1second(); // 1秒間開ける
                            break;
                        }
                    } else {
                        System.out.println("エラーが発生しました。正しいキーを押してください。");
                    }

                    Action.actionStop1second(); // 1秒間開ける
                    System.out.println();
                    System.out.println("現在：" + floor + "/1,048,576です。");
                    Action.actionStop1second(); // 1秒間開ける
                }

                while (true) {
                    System.out.println("もう一度挑戦する場合は『Enter』ボタンを、やめる場合はその他のボタンを押してください。");

                    try {
                        int keyCode = System.in.read();
                        if (keyCode == 10) { // EnterキーのASCIIコード
                            break; // Enterキーが押されたら最初のループへ
                        } else {
                            System.out.println("ゲームを終了します。");
                            Action.actionStop1second(); // 1秒間開ける
                            System.out.println("次回の挑戦をお待ちしています。");
                            exit = true; // メインループを終了するためにフラグをセット
                            break;
                        }
                    } catch (IOException e) {
                        System.out.println("入力エラーが発生しました。再試行してください。");
                    }
                }
            }
        } finally {
            scanner.close(); // 最後にスキャナーを閉じる
            System.exit(0); // アプリケーションの終了
        }
    }
}